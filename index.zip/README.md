CSS Diner

This is a CSS Selector practice game.
